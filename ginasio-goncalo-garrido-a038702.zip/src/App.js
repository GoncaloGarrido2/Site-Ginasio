import React from 'react';

import Spump from './components/Spump';
import './global.css';

function App() {
  return <Spump />;
}

export default App;
